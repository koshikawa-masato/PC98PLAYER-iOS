Original transfer-practice demo for RetroDOS Player. MIT license.
Open the folder containing PC98PLAYER.INI and START.COM.
This is not a game, BIOS or ROM.
